#!/bin/sh

python -m compileall $1

